/**
 * Hub Vehicle Tracker — Google Apps Script backend
 *
 * Attach this script to the Google Spreadsheet:
 * Extensions > Apps Script
 *
 * Keep these tab names exactly, or edit TRACKERS below.
 */

/**
 * Paste the ID of the ORIGINAL tracker spreadsheet below.
 *
 * Original URL example:
 * https://docs.google.com/spreadsheets/d/1ABCxyz987/edit
 *
 * Spreadsheet ID is:
 * 1ABCxyz987
 */
const SOURCE_SPREADSHEET_ID = "PASTE_ORIGINAL_SPREADSHEET_ID_HERE";

const TRACKERS = [
  { sheetName: "RTO IB", movement: "IB" },
  { sheetName: "RTO OB", movement: "OB" },
  { sheetName: "FWD IB", movement: "IB" },
  { sheetName: "FWD OB", movement: "OB" }
];

const HISTORY_LIMIT = 50;
const TIMEZONE = Session.getScriptTimeZone() || "Asia/Kolkata";

function doGet(e) {
  try {
    const action = cleanText_(e && e.parameter && e.parameter.action).toLowerCase();

    if (action === "health") {
      return json_({ ok: true, service: "Hub Vehicle Tracker", time: new Date().toISOString() });
    }

    if (action !== "search") {
      return json_({
        ok: false,
        error: "Use ?action=search&q=VALUE&type=auto|dock|vehicle"
      });
    }

    const query = cleanText_(e.parameter.q);
    const requestedType = cleanText_(e.parameter.type || "auto").toLowerCase();

    if (!query) return json_({ ok: false, error: "Search value is required." });

    const type = requestedType === "auto" ? detectSearchType_(query) : requestedType;
    if (!["dock", "vehicle"].includes(type)) {
      return json_({ ok: false, error: "Search type must be auto, dock or vehicle." });
    }

    const allRows = readAllTrackers_();
    const normalizedQuery = normalizeSearch_(query.replace(/^dock[\s-]*/i, ""));

    let matches = allRows.filter(row => {
      if (type === "dock") {
        return normalizeSearch_(row.dockNo) === normalizedQuery;
      }
      return normalizeSearch_(row.vehicle).includes(normalizedQuery);
    });

    matches.sort((a, b) => (b.lastActivitySort || 0) - (a.lastActivitySort || 0));

    let active;
    let history;

    if (type === "dock") {
      // A dock can hold more than one active vehicle. A vehicle counts as
      // physically placed only after Dock In and before Dock Out.
      active = matches.filter(row => row.isAtDock);
      history = matches.filter(row => !row.isAtDock).slice(0, HISTORY_LIMIT);
    } else {
      // A vehicle can have multiple trips. Return every currently open trip,
      // newest first, then all completed trips as history.
      active = matches.filter(row => row.isActive);
      history = matches.filter(row => !row.isActive).slice(0, HISTORY_LIMIT);

      // If bad data leaves multiple old trips open, mark older open entries.
      if (active.length > 1) {
        const newest = active[0].lastActivitySort || 0;
        active = active.map((row, index) => {
          if (index === 0) return row;
          const ageHours = newest && row.lastActivitySort
            ? (newest - row.lastActivitySort) / 3600000
            : 0;
          if (ageHours > 18) {
            return Object.assign({}, row, {
              status: row.status + " · Possible old open entry",
              dataWarning: "Dock Out may be missing in an older trip"
            });
          }
          return row;
        });
      }
    }

    return json_({
      ok: true,
      query: query,
      type: type,
      active: active,
      history: history,
      matched: matches.length
    });
  } catch (error) {
    return json_({
      ok: false,
      error: error && error.message ? error.message : String(error)
    });
  }
}

function readAllTrackers_() {
  if (!SOURCE_SPREADSHEET_ID || SOURCE_SPREADSHEET_ID.includes("PASTE_ORIGINAL")) {
    throw new Error("Paste the original tracker Spreadsheet ID in SOURCE_SPREADSHEET_ID.");
  }

  // Standalone project owned by you. It reads the original tracker using
  // the permissions of the account that deploys this web app.
  const spreadsheet = SpreadsheetApp.openById(SOURCE_SPREADSHEET_ID);
  const records = [];

  TRACKERS.forEach(config => {
    const sheet = spreadsheet.getSheetByName(config.sheetName);
    if (!sheet) return;

    const values = sheet.getDataRange().getValues();
    const display = sheet.getDataRange().getDisplayValues();
    if (values.length < 2) return;

    const headers = display[0].map(normalizeHeader_);
    const indexes = createIndexMap_(headers);

    for (let rowIndex = 1; rowIndex < values.length; rowIndex++) {
      const rawRow = values[rowIndex];
      const shownRow = display[rowIndex];

      const vehicle = field_(shownRow, indexes, ["vehicle", "vehicleno", "vehiclenumber"]);
      const dockNo = field_(shownRow, indexes, ["dockno", "docknumber", "dock"]);

      // Ignore fully empty/non-operational rows.
      if (!vehicle && !dockNo) continue;

      const record = buildRecord_(
        rawRow,
        shownRow,
        indexes,
        config.sheetName,
        config.movement,
        rowIndex + 1
      );
      records.push(record);
    }
  });

  return records;
}

function buildRecord_(rawRow, shownRow, indexes, tracker, movement, sheetRow) {
  const dateDisplay = field_(shownRow, indexes, ["date"]);
  const dateRaw = rawField_(rawRow, indexes, ["date"]);

  const arrivalAliases = movement === "IB"
    ? ["vehiclearrived", "gateintime", "gatein"]
    : ["gateintime", "gatein", "vehiclearrived"];

  const operationAliases = movement === "IB"
    ? ["unloadtime", "unloadingtime"]
    : ["loadingtime", "loadtime"];

  const arrivalDisplay = field_(shownRow, indexes, arrivalAliases);
  const dockInDisplay = field_(shownRow, indexes, ["dockin"]);
  const operationDisplay = field_(shownRow, indexes, operationAliases);
  const dockOutDisplay = field_(shownRow, indexes, ["dockout"]);

  const arrivalRaw = rawField_(rawRow, indexes, arrivalAliases);
  const dockInRaw = rawField_(rawRow, indexes, ["dockin"]);
  const operationRaw = rawField_(rawRow, indexes, operationAliases);
  const dockOutRaw = rawField_(rawRow, indexes, ["dockout"]);

  const timeline = buildTimeline_(
    dateRaw,
    [arrivalRaw, dockInRaw, operationRaw, dockOutRaw]
  );

  const statusInfo = statusFor_(
    movement,
    arrivalDisplay,
    dockInDisplay,
    operationDisplay,
    dockOutDisplay,
    field_(shownRow, indexes, ["dockno", "docknumber", "dock"])
  );

  return {
    tracker: tracker,
    movement: movement,
    sheetRow: sheetRow,
    date: dateDisplay,
    shift: field_(shownRow, indexes, ["shift"]),
    vehicleType: field_(shownRow, indexes, ["vehicletype"]),
    regularAdhoc: field_(shownRow, indexes, ["regularadhoc", "regularoradhoc"]),
    dockNo: field_(shownRow, indexes, ["dockno", "docknumber", "dock"]),
    vehicle: field_(shownRow, indexes, ["vehicle", "vehicleno", "vehiclenumber"]),
    tripId: field_(shownRow, indexes, ["tripid"]),
    consignment: field_(shownRow, indexes, [
      "consignment", "consignmentid", "consignmentids"
    ]),
    route: field_(shownRow, indexes, ["route"]),
    arrivalTime: arrivalDisplay,
    dockIn: dockInDisplay,
    operationTime: operationDisplay,
    dockOut: dockOutDisplay,
    status: statusInfo.status,
    currentPlace: statusInfo.currentPlace,
    isActive: statusInfo.isActive,
    isAtDock: statusInfo.isAtDock,
    lastActivitySort: timeline.lastActivity
      ? timeline.lastActivity.getTime()
      : dateToMillis_(dateRaw),
    totalBags: field_(shownRow, indexes, [
      "totalbags", "bagcount", "bagcounttotal"
    ]),
    totalShipments: field_(shownRow, indexes, [
      "totalshipments", "totalshipmentsbagsl", "totalshipmentsbagsl",
      "totaldepartedintcapp", "unitintcrec", "unitintcrecived", "unitintcreceived"
    ]),
    employeeName: field_(shownRow, indexes, ["employeename", "deoname"]),
    employeeId: field_(shownRow, indexes, ["employeeid", "deoid"]),
    driverName: field_(shownRow, indexes, ["drivername"]),
    driverContact: field_(shownRow, indexes, ["drivercontact"]),
    dataWarning: ""
  };
}

function statusFor_(movement, arrival, dockIn, operation, dockOut, dockNo) {
  if (dockOut) {
    return {
      status: "Departed",
      currentPlace: movement === "OB" ? "In Transit" : "Dock Released",
      isActive: false,
      isAtDock: false
    };
  }

  if (dockIn) {
    if (operation) {
      return {
        status: movement === "IB"
          ? "Unloading Completed – Waiting for Dock Out"
          : "Loading Completed – Waiting for Dock Out",
        currentPlace: dockNo ? "Dock " + dockNo : "At Dock",
        isActive: true,
        isAtDock: true
      };
    }

    return {
      status: movement === "IB" ? "Unloading" : "Loading",
      currentPlace: dockNo ? "Dock " + dockNo : "At Dock",
      isActive: true,
      isAtDock: true
    };
  }

  if (arrival) {
    return {
      status: "Waiting for Dock",
      currentPlace: "Yard",
      isActive: true,
      isAtDock: false
    };
  }

  return {
    status: "Vehicle Not Arrived",
    currentPlace: "Outside Hub",
    isActive: true,
    isAtDock: false
  };
}

function buildTimeline_(baseDateValue, eventValues) {
  const base = dateOnly_(baseDateValue);
  let previous = null;
  let lastActivity = base;

  eventValues.forEach(value => {
    const eventDate = combineDateAndTime_(base, value, previous);
    if (eventDate) {
      previous = eventDate;
      lastActivity = eventDate;
    }
  });

  return { lastActivity: lastActivity };
}

function combineDateAndTime_(baseDate, value, previous) {
  if (value === "" || value === null || value === undefined) return null;

  let candidate;

  if (value instanceof Date && !isNaN(value)) {
    // Full date stored in the cell.
    if (value.getFullYear() > 2000) {
      candidate = new Date(value.getTime());
    } else {
      candidate = new Date(baseDate.getTime());
      candidate.setHours(value.getHours(), value.getMinutes(), value.getSeconds(), 0);
    }
  } else {
    const parsed = parseTimeText_(String(value));
    if (!parsed) return null;
    candidate = new Date(baseDate.getTime());
    candidate.setHours(parsed.hours, parsed.minutes, parsed.seconds, 0);
  }

  // Night-shift protection: a time after midnight belongs to the next date
  // when it would otherwise be more than 6 hours earlier than the previous step.
  if (previous && candidate.getTime() < previous.getTime() - 6 * 3600000) {
    candidate.setDate(candidate.getDate() + 1);
  }

  return candidate;
}

function parseTimeText_(text) {
  const value = cleanText_(text).toUpperCase();
  const match = value.match(/(\d{1,2})[:.](\d{2})(?::(\d{2}))?\s*(AM|PM)?/);
  if (!match) return null;

  let hours = Number(match[1]);
  const minutes = Number(match[2]);
  const seconds = Number(match[3] || 0);
  const ampm = match[4];

  if (ampm === "PM" && hours < 12) hours += 12;
  if (ampm === "AM" && hours === 12) hours = 0;

  return { hours: hours, minutes: minutes, seconds: seconds };
}

function dateOnly_(value) {
  if (value instanceof Date && !isNaN(value)) {
    return new Date(value.getFullYear(), value.getMonth(), value.getDate());
  }

  const parsed = new Date(value);
  if (!isNaN(parsed)) {
    return new Date(parsed.getFullYear(), parsed.getMonth(), parsed.getDate());
  }

  return new Date(2000, 0, 1);
}

function dateToMillis_(value) {
  const date = dateOnly_(value);
  return date ? date.getTime() : 0;
}

function createIndexMap_(headers) {
  const map = {};
  headers.forEach((header, index) => {
    if (header && map[header] === undefined) map[header] = index;
  });
  return map;
}

function field_(row, indexes, aliases) {
  for (let i = 0; i < aliases.length; i++) {
    const index = indexes[normalizeHeader_(aliases[i])];
    if (index !== undefined) {
      const value = cleanText_(row[index]);
      if (value) return value;
    }
  }
  return "";
}

function rawField_(row, indexes, aliases) {
  for (let i = 0; i < aliases.length; i++) {
    const index = indexes[normalizeHeader_(aliases[i])];
    if (index !== undefined && row[index] !== "" && row[index] !== null) {
      return row[index];
    }
  }
  return "";
}

function normalizeHeader_(value) {
  return cleanText_(value)
    .toLowerCase()
    .replace(/&/g, "and")
    .replace(/[^a-z0-9]/g, "");
}

function normalizeSearch_(value) {
  return cleanText_(value).toUpperCase().replace(/[^A-Z0-9]/g, "");
}

function cleanText_(value) {
  return value === null || value === undefined
    ? ""
    : String(value).replace(/\s+/g, " ").trim();
}

function detectSearchType_(query) {
  const normalized = cleanText_(query).replace(/^dock[\s-]*/i, "");
  return /^\d{1,3}$/.test(normalized) ? "dock" : "vehicle";
}

function json_(object) {
  return ContentService
    .createTextOutput(JSON.stringify(object))
    .setMimeType(ContentService.MimeType.JSON);
}
